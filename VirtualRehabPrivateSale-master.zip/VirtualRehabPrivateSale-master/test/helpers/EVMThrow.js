const EVMThrow = 'invalid opcode';

module.exports = {
  EVMThrow,
};
